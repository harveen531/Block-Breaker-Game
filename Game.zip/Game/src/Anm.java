
public class Anm implements Runnable{
	BlockPanel bp;
	Anm(BlockPanel p)
	{
		bp=p;
	}
	public void run()
	{
		while(true)
		{	bp.update();	
	try {
		Thread.sleep(15);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	}
}
