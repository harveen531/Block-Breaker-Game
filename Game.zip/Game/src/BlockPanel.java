import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.event.*;
import java.awt.*;

public class BlockPanel extends JPanel implements KeyListener{
	ArrayList<Blocks> block=new ArrayList <Blocks>();
	ArrayList<Blocks> ball=new ArrayList<Blocks>();
	ArrayList<Blocks> powerup=new ArrayList<Blocks>();
		Anm a;
	Thread t;
	int enter=0;
	Blocks slider=new Blocks(190,500,100,23,"slider.png");
	BlockPanel()
	{ 		 //making list of blocks
		
		for(int i=0;i<8;i++)
		block.add(new Blocks((i*60+2),0,60,25,"r7.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),25,60,25,"r5.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),50,60,25,"r8.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),75,60,25,"r11.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),100,60,25,"r1.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),125,60,25,"r10.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),150,60,25,"r2.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),175,60,25,"r12.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),200,60,25,"r4.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),225,60,25,"r3.png"));
		for(int i=0;i<8;i++)
			block.add(new Blocks((i*60+2),250,60,25,"r6.png"));
				       
		  Random r=new Random();
		  for(int j=0;j<7;j++)
		  {
		  block.get(r.nextInt(87)).power=true;
		  }
		  ball.add(new Blocks(230,460,25,25,"ball.png"));
            addKeyListener(this);
            //To give focus to panel
            setFocusable(true);
	}
	//drawing blocks to panel
	public void paintComponent(Graphics g)
	{ 
		super.paintComponent(g);
			for(Blocks p:powerup)
		{
			p.draw(g,this);
		}
			for(Blocks b:block)
		{
			b.draw(g, this);
		}
			for(Blocks bal:ball)
			{
				bal.draw(g, this);
			}
		slider.draw(g,this);
	}
	//repaint when changes occur
	@SuppressWarnings("deprecation")
	public void update()
	{
		int flag=0;
		int f1=0;
		for(Blocks ba:block)
		{
			if(ba.destroy==false)
				f1=1;
		}
		for(Blocks b:ball)
		{
			if(b.destroy==false)
				flag=1;
		}
		  if(flag==0||f1==0)
		  {
			  
 			  JDialog jd=new JDialog();
 			  jd.setTitle("GAME OVER");
			   jd.setLocation(450,250);
			   jd.setLayout(new FlowLayout());
			   jd.setSize(300,250);
			   if(flag==0)
			   {
				JLabel lab1=new JLabel();
				lab1.setText("     Oops!!!YOU LOSE!");
				lab1.setIcon(new ImageIcon("sad1.jpg"));
				lab1.setIconTextGap(-180);
				JLabel lab2=new JLabel();
				lab2.setText("Better Luck Next Time");
				lab2.setIcon(new ImageIcon("thumb.jpg"));
				lab2.setIconTextGap(-180);
				jd.add(lab1);
				jd.add(lab2);
			   }
			   if(f1==0)
			   {
				   JLabel lab1=new JLabel();
				   lab1.setText("                 YOU WON              ");
				   JLabel lab2=new JLabel();
				   lab2.setIcon(new ImageIcon("winner.jpg"));
				   jd.add(lab1);
				   jd.add(lab2);
			   }
			   jd.add(new JLabel("         What do you want to do?     "));
			   JButton but1=new JButton("Start Again");
			   JButton but2=new JButton("End Game");
			   jd.add(but1);
			   jd.add(but2);
		       jd.setVisible(true);
		       jd.setModal(true);
		         but1.addActionListener(new ActionListener(){
		        	public void actionPerformed(ActionEvent e)
		        	{
		             jd.setVisible(false);
		        	Game.restart();	
		        	}
		         });
		         but2.addActionListener(new ActionListener(){
			        	public void actionPerformed(ActionEvent e)
			        	{
			        		Game.close();
			        	}
			         });
		         t.stop();
		  }
		for(Blocks pw:powerup)
		{
			pw.y+=1;
			if(pw.intersects(slider)&& pw.destroy==false)
			{
				pw.destroy=true;
				ball.add(new Blocks(slider.x+75,460,25,25,"ball.png"));
			}
		}
		for(Blocks b:ball)
		{

			b.x+=b.ballx;
			b.y+=b.bally;
		if(b.x>(getWidth()-25)||b.x<0)
		{
			b.ballx*=-1;
		}
		if(b.y<10|| slider.intersects(b))
			{b.bally*=-1;}
		if(b.y>getHeight())
			b.destroy=true;
		for(Blocks ba:block)
		{
			if((ba.left.intersects(b)||ba.right.intersects(b))&& ba.destroy==false)
			{
				if(ba.power==true)
				{
					powerup.add(new Blocks(b.x,b.y,30,30,"star.png"));
				}
				ba.destroy=true;
				b.ballx*=-1;
			    b.x+=b.ballx;
			}
	
			else if(b.intersects(ba)&& ba.destroy==false)
			{
				if(ba.power==true)
				{
					powerup.add(new Blocks(b.x,b.y,30,30,"star.png"));
				}
				ba.destroy=true;
				b.bally*=-1;
				 b.y+=b.bally;
			}
		}
		
		
	
		}	
		
		repaint();
	}
	//handling key events and starting the slider and moving it
	public void keyPressed(KeyEvent e)
	{
		
		if(e.getKeyCode()==KeyEvent.VK_ENTER && enter==0)
		{
			enter++;
			a=new Anm(this);
			t=new Thread(a);
				t.start();
		}
		if((e.getKeyCode()==KeyEvent.VK_LEFT)&& slider.x>14)
			slider.x-=30;
		else if((e.getKeyCode()==KeyEvent.VK_RIGHT )&& slider.x<(getWidth()-slider.getWidth()-14))
			slider.x+=30;
	}
	public void keyTyped(KeyEvent e)
	{
		
	}
	public void keyReleased(KeyEvent e)
	{
		
	}
}
