import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;

public class Blocks extends Rectangle {
	Image i;
	int ballx=3,bally=-3;
	boolean destroy=false;
	boolean power=false;
	Rectangle left,right,up;
Blocks(int a,int b,int c,int d,String s)
{
	
//The attributes of rectangle 
	x=a;
	y=b;
	width=c;
	height=d;
	 left=new Rectangle(a-1,b,1,d);
	right=new Rectangle(a+c+1,b,1,d);
	up=new Rectangle(a,b+d,c,1);
// Image that would be dispalyed
	i=Toolkit.getDefaultToolkit().getImage(s);
}
public void draw(Graphics g,Component c)
{
	if(!destroy)
g.drawImage(i, x, y, width,height,c);	
	
	
}
}
