import java.awt.FlowLayout;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

public class Game {
	  public static JFrame jf;
	  static int x=0;
	{
		jf=new JFrame("Block Breaker Game");
		BlockPanel p=new BlockPanel();
		jf.getContentPane().add(p);
		jf.setVisible(true);
	    jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setSize(490,600);
		jf.setResizable(false);
		jf.setLocation(400,60);
		JDialog d=new JDialog( );
		ScheduledExecutorService s = Executors.newSingleThreadScheduledExecutor();     
		s.schedule(new Runnable() {
		    public void run() {
		        d.setVisible(false); 
		        d.dispose();
		    }
		}, 3, TimeUnit.SECONDS);

            d.setTitle("Start Game");
		    d.setLocation(450,250);
			d.setLayout(new FlowLayout());
		  	d.setSize(400,200);
		  	if(x==0)
      	 	{
		  	d.setVisible(true);
      	 	x++;
      	 	}
			d.setModal(true);
		    JLabel jlab[]=new JLabel[4];
		    for(int i=0;i<4;i++)
		    jlab[i]=new JLabel();
		    jlab[0].setText("After DialogBox Closes Press");
	        jlab[1].setText("To Start The GAME");
		    jlab[1].setIcon(new ImageIcon("enter1.png"));
		    jlab[2].setText("Use Left Arrow Key To Move Slider Left");
		    jlab[2].setIcon(new ImageIcon("left.png"));
		    jlab[2].setIconTextGap(-290);
		    jlab[3].setText("Use Left Arrow Key To Move Slider Right");
		    jlab[3].setIcon(new ImageIcon("right.png"));
		    jlab[3].setIconTextGap(-290);
		    
		    for(int i=0;i<4;i++)
		    d.add(jlab[i]);
		   
	}
	public static void restart()
	{
		jf.setVisible(false);
			SwingUtilities.invokeLater(new Runnable(){
			public void run() {
				new Game();
			}
		});
		
	}
	public static void close()
	{
	System.exit(0);
	}

	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable(){
			public void run() {
				new Game();
			}
		});
			
		
	}
}


